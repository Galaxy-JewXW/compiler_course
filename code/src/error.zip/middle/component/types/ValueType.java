package middle.component.types;

public abstract class ValueType {
}
