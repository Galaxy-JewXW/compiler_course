package middle.component.types;

public interface Assignable {
}
