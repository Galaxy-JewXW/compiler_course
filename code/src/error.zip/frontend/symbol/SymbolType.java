package frontend.symbol;

public enum SymbolType {
    VOID,
    INT32,
    INT8
}
