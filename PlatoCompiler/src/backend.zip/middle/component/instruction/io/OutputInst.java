package middle.component.instruction.io;

public interface OutputInst {
    boolean constContent();

    String getConstContent();
}
