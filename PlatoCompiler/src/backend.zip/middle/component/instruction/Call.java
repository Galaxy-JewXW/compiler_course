package middle.component.instruction;

import middle.component.Function;

public interface Call {
    Function getCalledFunction();
    String getCallee();
}
