package middle.component.type;

public class ValueType {
    protected ValueType() {
    }
}
