package middle.symbol;

public enum SymbolType {
    VOID,
    INT,
    CHAR
}
