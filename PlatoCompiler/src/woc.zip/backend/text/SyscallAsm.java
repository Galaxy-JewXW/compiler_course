package backend.text;

public class SyscallAsm extends TextAssembly {
    @Override
    public String toString() {
        return "syscall";
    }
}
