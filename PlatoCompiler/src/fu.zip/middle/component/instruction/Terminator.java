package middle.component.instruction;

public interface Terminator {
}
