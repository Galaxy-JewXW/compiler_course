package frontend.symbol;

public enum SymbolType {
    VOID,
    INT,
    CHAR
}
