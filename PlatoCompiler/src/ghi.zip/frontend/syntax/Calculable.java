package frontend.syntax;

public interface Calculable {
    int calculate();
}
