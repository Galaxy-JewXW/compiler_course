package frontend.syntax;

// 声明 Decl → ConstDecl | VarDecl
// 覆盖两种声明
public abstract class Decl extends SyntaxNode {
}
