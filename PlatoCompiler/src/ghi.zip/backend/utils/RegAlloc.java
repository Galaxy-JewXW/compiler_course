package backend.utils;

import backend.enums.Register;
import middle.component.BasicBlock;
import middle.component.ConstInt;
import middle.component.ConstString;
import middle.component.Function;
import middle.component.Module;
import middle.component.instruction.Instruction;
import middle.component.instruction.PhiInst;
import middle.component.instruction.ZextInst;
import middle.component.model.Value;
import optimize.Mem2Reg;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.PriorityQueue;

/**
 * 结合引用计数和线性扫描的寄存器分配器。
 */
public class RegAlloc {
    // 活跃变量分析映射
    private static HashMap<BasicBlock, HashSet<Value>> inMap;    // 每个基本块的入口活跃变量集合
    private static HashMap<BasicBlock, HashSet<Value>> outMap;   // 每个基本块的出口活跃变量集合
    private static HashMap<BasicBlock, HashSet<Value>> defMap;   // 定义集合：先赋值后使用的变量
    private static HashMap<BasicBlock, HashSet<Value>> useMap;   // 使用集合：先使用后赋值的变量

    // 寄存器分配
    private static ArrayList<Register> registerPool;             // 可用寄存器池
    private static int registerCount;                            // 寄存器数量
    private static HashMap<Value, Register> varToRegMap;         // 变量到寄存器的映射
    private static HashSet<Value> spilledVars;                   // 需要溢出的变量

    // 引用计数和活跃区间
    private static HashMap<Value, Integer> refCountMap;          // 变量的引用计数
    private static HashMap<Value, Interval> intervalMap;         // 变量的活跃区间

    public static void run(Module module) {
        Mem2Reg.run(module, false);

        registerPool = new ArrayList<>();
        for (Register register : Register.values()) {
            if (register.ordinal() >= Register.T0.ordinal() && register.ordinal() <= Register.T9.ordinal()) {
                registerPool.add(register);
            }
        }
        registerCount = registerPool.size();

        for (Function function : module.getFunctions()) {
            initLiveVariableAnalysis(function);
            computeInOutSets(function);
            computeReferenceCounts(function);
            computeLiveIntervals(function);
            allocateRegisters();
            function.setVar2reg(varToRegMap);
        }
    }

    /**
     * 初始化给定函数的活跃变量分析数据结构。
     */
    private static void initLiveVariableAnalysis(Function function) {
        inMap = new HashMap<>();
        outMap = new HashMap<>();
        defMap = new HashMap<>();
        useMap = new HashMap<>();

        for (BasicBlock block : function.getBasicBlocks()) {
            inMap.put(block, new HashSet<>());
            outMap.put(block, new HashSet<>());
            defMap.put(block, new HashSet<>());
            useMap.put(block, new HashSet<>());
            computeDefUseSets(block);
        }
    }

    /**
     * 计算给定基本块的定义和使用集合。
     */
    private static void computeDefUseSets(BasicBlock block) {
        HashSet<Value> defSet = defMap.get(block);
        HashSet<Value> useSet = useMap.get(block);

        // 特别处理 Phi 指令
        for (Instruction instruction : block.getInstructions()) {
            if (instruction instanceof PhiInst) {
                for (Value value : instruction.getOperands()) {
                    if (!(value instanceof ConstInt || value instanceof ConstString) && !defSet.contains(value)) {
                        useSet.add(value);
                    }
                }
                if (!instruction.getName().isEmpty()) {
                    defSet.add(instruction);
                }
            }
        }

        // 处理其他指令
        for (Instruction instruction : block.getInstructions()) {
            if (!(instruction instanceof PhiInst)) {
                for (Value operand : instruction.getOperands()) {
                    if (!(operand instanceof ConstInt || operand instanceof ConstString) && !defSet.contains(operand)) {
                        useSet.add(operand);
                    }
                }
                if (!instruction.getName().isEmpty() && !(instruction instanceof ZextInst)) {
                    defSet.add(instruction);
                }
            }
        }
    }

    /**
     * 计算函数中每个基本块的活跃入口和出口集合。
     */
    private static void computeInOutSets(Function function) {
        ArrayList<BasicBlock> blocks = function.getBasicBlocks();
        boolean changed = true;

        // 迭代进行数据流分析，直到集合不再发生变化
        while (changed) {
            changed = false;
            for (int i = blocks.size() - 1; i >= 0; i--) {
                BasicBlock block = blocks.get(i);
                HashSet<Value> outSet = new HashSet<>();
                // 出口集合是所有后继块的入口集合的并集
                for (BasicBlock successor : block.getNextBlocks()) {
                    outSet.addAll(inMap.get(successor));
                }
                outMap.put(block, outSet);

                HashSet<Value> inSet = new HashSet<>(outSet);
                // 入口集合 = （出口集合 - 定义集合）∪ 使用集合
                inSet.removeAll(defMap.get(block));
                inSet.addAll(useMap.get(block));

                if (!inSet.equals(inMap.get(block))) {
                    changed = true;
                    inMap.put(block, inSet);
                }
            }
        }
    }

    /**
     * 计算变量的引用计数，考虑循环中的变量增加权值。
     */
    private static void computeReferenceCounts(Function function) {
        refCountMap = new HashMap<>();
        for (BasicBlock block : function.getBasicBlocks()) {
            for (Instruction instruction : block.getInstructions()) {
                for (Value operand : instruction.getOperands()) {
                    if (!(operand instanceof ConstInt || operand instanceof ConstString)) {
                        int weight = 1; // 在循环内的变量权值加倍
                        refCountMap.put(operand, refCountMap.getOrDefault(operand, 0) + weight);
                    }
                }
                if (!instruction.getName().isEmpty() && !(instruction instanceof ZextInst)) {
                    // 定义的变量也计入引用计数
                    refCountMap.put(instruction, refCountMap.getOrDefault(instruction, 0));
                }
            }
        }
    }

    /**
     * 计算变量的活跃区间。
     */
    private static void computeLiveIntervals(Function function) {
        intervalMap = new HashMap<>();
        HashMap<Value, Integer> firstUseMap = new HashMap<>();
        HashMap<Value, Integer> lastUseMap = new HashMap<>();

        int position = 0;
        for (BasicBlock block : function.getBasicBlocks()) {
            for (Instruction instruction : block.getInstructions()) {
                position++;
                for (Value operand : instruction.getOperands()) {
                    if (!(operand instanceof ConstInt || operand instanceof ConstString)) {
                        firstUseMap.putIfAbsent(operand, position);
                        lastUseMap.put(operand, position);
                    }
                }
                if (!instruction.getName().isEmpty() && !(instruction instanceof ZextInst)) {
                    firstUseMap.putIfAbsent(instruction, position);
                    lastUseMap.put(instruction, position);
                }
            }
        }

        // 创建活跃区间
        for (Value var : firstUseMap.keySet()) {
            Interval interval = new Interval(firstUseMap.get(var), lastUseMap.get(var), var);
            intervalMap.put(var, interval);
        }
    }

    /**
     * 分配寄存器，结合引用计数和线性扫描。
     */
    private static void allocateRegisters() {
        varToRegMap = new HashMap<>();
        spilledVars = new HashSet<>();

        // 获取所有活跃区间并排序
        List<Interval> intervals = new ArrayList<>(intervalMap.values());
        // 按活跃区间的开始位置排序，当开始位置相同时，引用次数多的变量排在前面
        intervals.sort((a, b) -> {
            if (a.start != b.start) {
                return Integer.compare(a.start, b.start);
            } else {
                return Integer.compare(refCountMap.getOrDefault(b.variable, 0),
                        refCountMap.getOrDefault(a.variable, 0));
            }
        });

        PriorityQueue<Interval> active = new PriorityQueue<>(Comparator.comparingInt(a -> a.end));
        for (Interval interval : intervals) {
            // 过期旧的活跃区间
            Iterator<Interval> iterator = active.iterator();
            while (iterator.hasNext()) {
                Interval activeInterval = iterator.next();
                if (activeInterval.end >= interval.start) {
                    break;
                }
                // 释放寄存器
                iterator.remove();
            }

            if (active.size() >= registerCount) {
                // 寄存器不足，选择引用计数最小的变量进行溢出
                Interval spillInterval = selectSpillInterval(active);
                if (spillInterval != null && refCountMap.getOrDefault(spillInterval.variable, 0)
                        < refCountMap.getOrDefault(interval.variable, 0)) {
                    // 溢出spillInterval
                    active.remove(spillInterval);
                    spilledVars.add(spillInterval.variable);
                    // 分配其寄存器给当前变量
                    varToRegMap.put(interval.variable, varToRegMap.get(spillInterval.variable));
                    active.add(interval);
                } else {
                    // 溢出当前变量
                    spilledVars.add(interval.variable);
                }
            } else {
                // 分配寄存器
                Register reg = allocateRegister(active);
                varToRegMap.put(interval.variable, reg);
                active.add(interval);
            }
        }
    }

    /**
     * 选择需要溢出的活跃区间。
     */
    private static Interval selectSpillInterval(PriorityQueue<Interval> active) {
        // 寻找引用计数最小的变量
        Interval spillInterval = null;
        int minRefCount = Integer.MAX_VALUE;
        for (Interval interval : active) {
            int refCount = refCountMap.getOrDefault(interval.variable, 0);
            if (refCount < minRefCount) {
                minRefCount = refCount;
                spillInterval = interval;
            }
        }
        return spillInterval;
    }

    /**
     * 分配一个未被使用的寄存器。
     */
    private static Register allocateRegister(PriorityQueue<Interval> active) {
        HashSet<Register> usedRegs = new HashSet<>();
        for (Interval interval : active) {
            usedRegs.add(varToRegMap.get(interval.variable));
        }
        for (Register reg : registerPool) {
            if (!usedRegs.contains(reg)) {
                return reg;
            }
        }
        return null;
    }

    /**
     * 活跃区间类，记录变量的开始和结束位置。
     */
    private static class Interval {
        int start;
        int end;
        Value variable;

        Interval(int start, int end, Value variable) {
            this.start = start;
            this.end = end;
            this.variable = variable;
        }
    }
}
