package backend;

public abstract class Assembly {

}
