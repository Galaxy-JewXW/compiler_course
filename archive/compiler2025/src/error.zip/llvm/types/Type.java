package llvm.types;

public interface Type {
}
