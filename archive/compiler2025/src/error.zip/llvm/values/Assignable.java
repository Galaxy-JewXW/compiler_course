package llvm.values;

public interface Assignable {
}
